#ifndef ISERVERGAMEENTS_H
#define ISERVERGAMEENTS_H

#include "SdkPreprocessors.h"

#include "../../Interfaces/edict.h"

namespace SourceSdk
{
	class CBaseEntity;
};

#include "IServerGameEnts001.h"

#endif // ISERVERGAMEENTS_H
